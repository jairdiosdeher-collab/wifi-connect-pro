import 'package:flutter_test/flutter_test.dart';
import 'package:wifi_connect_pro/models/wifi_network.dart';

void main() {
  test('interpreta datos nativos de señal y banda', () {
    final network = WifiNetwork.fromMap({'ssid': 'Casa', 'security': 'WPA2', 'level': 82, 'rssi': -48, 'frequency': 5180});
    expect(network.ssid, 'Casa');
    expect(network.band, '5 GHz');
    expect(network.signalLabel, 'Excelente');
  });
}
