# Notas de integración Android

- Escaneo: `WifiManager.startScan()` y `scanResults`, con permisos y límites del sistema.
- Conexión solicitada por el usuario: `WifiNetworkSpecifier` + `ConnectivityManager.requestNetwork()` (API 29+).
- Sugerencias: `WifiManager.addNetworkSuggestions()` (API 29+); esto no fuerza conexión inmediata.
- Estado: `WifiManager.connectionInfo` en compatibilidad con dispositivos, puede ocultar SSID sin permisos adecuados.
- El permiso de ubicación se solicita porque el sistema lo exige para resultados de escaneo en numerosas versiones Android. La app no utiliza los datos para rastrear ubicación.
