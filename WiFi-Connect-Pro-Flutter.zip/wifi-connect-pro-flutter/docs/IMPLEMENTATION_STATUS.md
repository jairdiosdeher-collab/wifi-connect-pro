# Estado de implementación — WiFi Connect Pro

## Incluido en el código fuente
- Flutter + Material Design 3, tema claro/oscuro/sistema y Riverpod para dependencias y tema.
- Escaneo de redes y estado de conexión mediante un MethodChannel Kotlin.
- Solicitudes de conexión mediante `WifiNetworkSpecifier` y sugerencias `WifiNetworkSuggestion` (Android 10+).
- Perfiles autorizados, historial SQLite, lector QR y exportación PDF.
- Campos SSID y detalles del historial cifrados AES-256-GCM con clave en almacenamiento seguro Android Keystore.
- Prueba de descarga manual de hasta 5 MB y registro local de muestras de RSSI.

## Límites importantes
- No se guardan contraseñas Wi-Fi ni se intentan obtener credenciales de terceros.
- `WifiNetworkSpecifier` crea una solicitud de red específica para la app; Android decide si la acepta. No garantiza una conexión persistente del sistema. Las sugerencias de red se deben aprobar/gestionar por Android.
- Android restringe frecuencia y resultados del escaneo. La app necesita permisos, Wi-Fi activado y, según la versión/fabricante, servicios de ubicación.
- El test de velocidad necesita Internet y puede consumir datos. El resultado es aproximado y depende del servidor y del tráfico.
- El “mapa de cobertura” de esta versión es un muestreo manual en cuadrícula, mantenido en memoria durante la sesión; no es una cartografía GPS, no se persiste ni es un plano calibrado.
- La clave está protegida por Android Keystore a través de `flutter_secure_storage`; la base SQLite completa no está cifrada con SQLCipher.
- No se ejecutó compilación ni análisis estático porque el entorno de generación no incluye Flutter/Dart/Android SDK.
- Si `gradle-wrapper.jar` no se encuentra en `android/gradle/wrapper/`, generar el wrapper desde Android Studio/Gradle antes de compilar.
