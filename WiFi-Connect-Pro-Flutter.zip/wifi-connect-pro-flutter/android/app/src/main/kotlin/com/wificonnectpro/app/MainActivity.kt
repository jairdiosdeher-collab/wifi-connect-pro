package com.wificonnectpro.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import android.net.wifi.WifiNetworkSpecifier
import android.net.wifi.WifiNetworkSuggestion
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val channelName = "com.wificonnectpro/wifi"
    private lateinit var wifiManager: WifiManager
    private lateinit var connectivityManager: ConnectivityManager
    private var activeRequestCallback: ConnectivityManager.NetworkCallback? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName).setMethodCallHandler { call, result ->
            when (call.method) {
                "scanNetworks" -> scanNetworks(result)
                "getConnectionStatus" -> result.success(connectionStatus())
                "connectWithSpecifier" -> {
                    val ssid = call.argument<String>("ssid")?.trim().orEmpty()
                    val password = call.argument<String>("password") ?: ""
                    val security = call.argument<String>("security") ?: "WPA2"
                    if (ssid.isBlank()) result.error("INVALID_SSID", "El SSID es obligatorio", null)
                    else connectWithSpecifier(ssid, password, security, result)
                }
                "addNetworkSuggestion" -> {
                    val ssid = call.argument<String>("ssid")?.trim().orEmpty()
                    val password = call.argument<String>("password") ?: ""
                    val security = call.argument<String>("security") ?: "WPA2"
                    addNetworkSuggestion(ssid, password, security, result)
                }
                "cancelConnectionRequest" -> {
                    activeRequestCallback?.let { try { connectivityManager.unregisterNetworkCallback(it) } catch (_: Exception) {} }
                    activeRequestCallback = null
                    result.success(true)
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun scanNetworks(result: MethodChannel.Result) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            result.error("PERMISSION_REQUIRED", "Concede permiso de ubicación para ver resultados del escaneo Wi-Fi en Android.", null)
            return
        }
        try {
            @Suppress("DEPRECATION")
            val started = wifiManager.startScan()
            mainHandler.postDelayed({
                try {
                    @Suppress("DEPRECATION")
                    val results = wifiManager.scanResults
                    val rows = results.distinctBy { it.SSID }.filter { it.SSID.isNotBlank() }.map { item ->
                        val security = when {
                            item.capabilities.contains("SAE") -> "WPA3"
                            item.capabilities.contains("WPA") -> "WPA/WPA2"
                            item.capabilities.contains("WEP") -> "WEP (obsoleto)"
                            else -> "Abierta / no identificada"
                        }
                        mapOf("ssid" to item.SSID, "bssid" to item.BSSID, "rssi" to item.level,
                            "level" to (((item.level + 100).coerceIn(0, 100))), "security" to security,
                            "frequency" to item.frequency, "capabilities" to item.capabilities)
                    }
                    result.success(rows)
                } catch (e: SecurityException) {
                    result.error("PERMISSION_DENIED", "Android no permitió leer el escaneo. Revisa permisos y ubicación.", e.message)
                } catch (e: Exception) {
                    result.error("SCAN_FAILED", e.localizedMessage ?: "No se pudo leer el escaneo", null)
                }
            }, if (started) 1200L else 500L)
        } catch (e: SecurityException) {
            result.error("PERMISSION_DENIED", "Android no permitió iniciar el escaneo", e.message)
        } catch (e: Exception) {
            result.error("SCAN_FAILED", e.localizedMessage ?: "Error de escaneo", null)
        }
    }

    private fun connectionStatus(): Map<String, Any?> {
        return try {
            @Suppress("DEPRECATION")
            val info = wifiManager.connectionInfo
            val connected = info != null && info.networkId != -1 && info.ssid != "<unknown ssid>"
            mapOf("connected" to connected,
                "ssid" to if (connected) info.ssid.trim('"') else null,
                "rssi" to if (connected) info.rssi else null,
                "level" to if (connected) wifiManager.calculateSignalLevel(info.rssi) * 25 else null,
                "linkSpeedMbps" to if (connected) info.linkSpeed else null)
        } catch (_: Exception) { mapOf("connected" to false, "ssid" to null, "rssi" to null, "level" to null, "linkSpeedMbps" to null) }
    }

    private fun connectWithSpecifier(ssid: String, password: String, security: String, result: MethodChannel.Result) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            result.error("UNSUPPORTED_VERSION", "WifiNetworkSpecifier requiere Android 10 o posterior. Usa Ajustes del sistema en este dispositivo.", null); return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            result.error("PERMISSION_REQUIRED", "Se requiere permiso de ubicación para esta operación en este dispositivo.", null); return
        }
        try {
            val builder = WifiNetworkSpecifier.Builder().setSsid(ssid)
            if (password.isNotEmpty()) {
                if (security.contains("WPA3", true)) builder.setWpa3Passphrase(password) else builder.setWpa2Passphrase(password)
            }
            val specifier = builder.build()
            val request = NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).setNetworkSpecifier(specifier).build()
            activeRequestCallback?.let { try { connectivityManager.unregisterNetworkCallback(it) } catch (_: Exception) {} }
            val callback = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    // La UI consulta el estado real por getConnectionStatus; no se vuelve a completar el MethodChannel.Result.
                }
                override fun onUnavailable() {
                    // La solicitud puede ser rechazada por el usuario o el sistema; el estado se refresca desde Flutter.
                    activeRequestCallback = null
                }
                override fun onLost(network: Network) { /* El sistema puede retirar la red cuando ya no se necesita. */ }
            }
            activeRequestCallback = callback
            connectivityManager.requestNetwork(request, callback)
            result.success(mapOf("accepted" to true, "pending" to true, "message" to "Solicitud enviada. Confirma el diálogo de Android si aparece.", "ssid" to ssid))
        } catch (e: IllegalArgumentException) {
            result.error("INVALID_CREDENTIALS", e.localizedMessage ?: "El tipo de seguridad o credencial no es válido", null)
        } catch (e: SecurityException) {
            result.error("PERMISSION_DENIED", "Android denegó la solicitud. Comprueba los permisos.", e.localizedMessage)
        } catch (e: Exception) {
            result.error("CONNECT_FAILED", e.localizedMessage ?: "No se pudo solicitar la conexión", null)
        }
    }

    private fun addNetworkSuggestion(ssid: String, password: String, security: String, result: MethodChannel.Result) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            result.error("UNSUPPORTED_VERSION", "WifiNetworkSuggestion requiere Android 10 o posterior.", null); return
        }
        if (ssid.isBlank()) { result.error("INVALID_SSID", "El SSID es obligatorio", null); return }
        try {
            val builder = WifiNetworkSuggestion.Builder().setSsid(ssid)
            if (password.isNotEmpty()) {
                if (security.contains("WPA3", true)) builder.setWpa3Passphrase(password) else builder.setWpa2Passphrase(password)
            }
            val status = wifiManager.addNetworkSuggestions(listOf(builder.build()))
            val success = status == WifiManager.STATUS_NETWORK_SUGGESTIONS_SUCCESS
            result.success(mapOf("accepted" to success, "status" to status,
                "message" to if (success) "Sugerencia registrada. Android decide si la usa y puede pedir aprobación." else "Android no aceptó la sugerencia."))
        } catch (e: Exception) { result.error("SUGGESTION_FAILED", e.localizedMessage ?: "No se pudo registrar la sugerencia", null) }
    }

    override fun onDestroy() {
        activeRequestCallback?.let { try { connectivityManager.unregisterNetworkCallback(it) } catch (_: Exception) {} }
        activeRequestCallback = null
        super.onDestroy()
    }
}
