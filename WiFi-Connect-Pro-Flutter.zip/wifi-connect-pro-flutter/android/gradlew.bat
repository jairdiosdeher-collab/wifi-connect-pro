@echo off
if exist "%~dp0gradle\wrapper\gradle-wrapper.jar" (
  java -classpath "%~dp0gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
  exit /b %ERRORLEVEL%
)
echo Falta gradle-wrapper.jar. Abre el proyecto en Android Studio o ejecuta gradle wrapper.
exit /b 1
