# WiFi Connect Pro — Flutter Android

Aplicación Android nativa en Flutter con interfaz oscura Material Design 3, SQLite local, escaneo real mediante `WifiManager`, solicitud de conexión por `WifiNetworkSpecifier`, sugerencias de red por `WifiNetworkSuggestion`, lectura de QR Wi-Fi e informe PDF.

## Abrir en Android Studio

1. Instala Flutter estable y Android Studio con Android SDK (API 35 recomendado).
2. Descomprime `WiFi-Connect-Pro-Flutter.zip`.
3. Abre la carpeta raíz del proyecto en Android Studio o ejecuta desde ella:

   ```bash
   flutter pub get
   flutter run
   ```

4. Usa un dispositivo Android físico para probar el escaneo y las solicitudes de conexión. El emulador normalmente no refleja redes Wi-Fi cercanas reales.

Para generar un APK de depuración:

```bash
flutter build apk --debug
```

El archivo se genera en `build/app/outputs/flutter-apk/app-debug.apk` después de instalar Flutter y descargar las dependencias. No se incluye un APK precompilado porque el entorno de generación no dispone de Flutter/Android SDK para compilar y probar el binario.

## Arquitectura

- `lib/models`: modelos de red, perfil autorizado e historial.
- `lib/data`: repositorio SQLite local (`sqflite`).
- `lib/services`: canal nativo Wi-Fi y exportación PDF.
- `lib/screens`: pantalla principal por pestañas y lector QR.
- `lib/widgets`: tarjetas de sección y diagnóstico de señal.
- `android/app/src/main/kotlin`: implementación Kotlin de las API Wi-Fi oficiales.

## Capacidades

- Escaneo de redes disponibles con SSID, BSSID, seguridad reportada, RSSI, porcentaje orientativo y banda/frecuencia.
- Solicitud de conexión a red guardada con `WifiNetworkSpecifier`. Android controla la aprobación y la disponibilidad. La solicitud no equivale a prometer una conexión silenciosa o permanente.
- Registro de `WifiNetworkSuggestion` disponible en el canal nativo para integración futura; Android decide si acepta/usa la sugerencia y puede requerir aprobación. La UI principal usa conexión explícita con consentimiento.
- Perfiles autorizados e historial en SQLite, sin guardar contraseñas.
- QR de formato estándar `WIFI:T:WPA;S:SSID;P:contraseña;;`. La contraseña del QR se mantiene en memoria solo para el flujo de conexión y no se persiste en la base de datos ni en historial.
- Diagnóstico de señal a partir de RSSI, historial y exportación de perfiles/eventos a PDF.
- Datos locales disponibles sin conexión. El escaneo, conexión y cámara requieren Wi-Fi/dispositivo/permisos.

## Límites importantes de Android

- Escaneo sujeto a versión del sistema, permisos runtime, Wi-Fi activado, ubicación y límites de frecuencia impuestos por Android.
- `WifiNetworkSpecifier` requiere Android 10 (API 29) o posterior. Se usa una solicitud de conexión iniciada por el usuario; el sistema puede mostrar diálogo y retirar la red cuando termina la solicitud.
- `WifiNetworkSuggestion` requiere Android 10 o posterior y no fuerza una conexión inmediata.
- No se intenta obtener contraseñas de terceros, romper seguridad, conectarse a redes no autorizadas ni evitar la confirmación del sistema.
- La señal en porcentaje es una escala visual orientativa, no una medición calibrada. La velocidad real no se mide en esta versión; una prueba de velocidad confiable requiere transferencia de datos y un endpoint/servicio, por lo que queda fuera de línea de base.
- No hay sincronización en nube en esta entrega; todos los datos se mantienen localmente.

## Permisos

El manifiesto declara permisos Wi-Fi, estado de red, ubicación para resultados de escaneo, dispositivos Wi-Fi cercanos para Android reciente y cámara para lectura QR. Se solicitan permisos runtime desde Flutter. Deniega cualquier permiso si no deseas usar esa función.

## Seguridad

- Las contraseñas no se guardan en SQLite, SharedPreferences ni historial.
- El texto de una contraseña escaneada desde QR solo se conserva temporalmente en memoria para presentar la solicitud de conexión.
- SQLite no está cifrada en esta versión. Evita almacenar información sensible adicional en ella. Para despliegue empresarial se recomienda cifrado de base de datos y revisión de seguridad independiente.
- No registrar credenciales en logs.

## Verificación

La estructura y el código se han preparado como proyecto fuente. Debes ejecutar `flutter pub get`, `flutter analyze` y probar en un dispositivo real. No se afirma compilación o pruebas en dispositivo realizadas desde este entorno.


## Mejoras de esta edición

- Riverpod (`ProviderScope`) para inyección de servicios y tema claro/oscuro/sistema.
- Prueba de descarga manual con un endpoint público de Cloudflare; descarga hasta 5 MB y requiere Internet. No se ejecuta automáticamente.
- Muestreo de cobertura local mediante RSSI en una cuadrícula; es una vista de sesión, no un mapa geográfico GPS y no se persiste todavía.
- Campos SSID y detalles de historial cifrados con AES-256-GCM; la clave se guarda en `flutter_secure_storage`, respaldado por Android Keystore. SQLite en sí no usa SQLCipher.
- Copias de seguridad Android desactivadas para reducir la exposición de datos locales.

## Preparación y compilación

1. Instala la versión estable de Flutter y Android Studio con Android SDK y Java 17.
2. Abre la carpeta raíz `wifi-connect-pro-flutter` en Android Studio.
3. Ejecuta `flutter pub get`. Si Android Studio solicita generar o actualizar el wrapper de Gradle, acepta la generación para la versión compatible con tu Flutter/Android Gradle Plugin instalado.
4. Conecta un teléfono Android 10+ con depuración USB o inicia un emulador y ejecuta `flutter run`.
5. Para APK: `flutter build apk --release`. Para AAB: `flutter build appbundle --release`.

**Estado de verificación:** este entorno no dispone del SDK de Flutter/Dart ni del SDK Android, por lo que no se pudo ejecutar `flutter analyze`, las pruebas ni compilar APK/AAB. El proyecto fuente se entrega para abrirlo y completar esa validación en un entorno Flutter real. El wrapper estándar de Gradle debe generarse en Android Studio si no está disponible en tu instalación.
