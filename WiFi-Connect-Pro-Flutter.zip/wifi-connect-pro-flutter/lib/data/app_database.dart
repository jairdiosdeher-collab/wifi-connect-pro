import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import '../models/authorized_profile.dart';
import '../models/connection_record.dart';
import '../services/secure_data_service.dart';

class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();
  final SecureDataService _secure = SecureDataService.instance;
  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    final root = await getDatabasesPath();
    _db = await openDatabase(p.join(root, 'wifi_connect_pro.db'), version: 2,
      onCreate: (db, version) async {
        await db.execute('CREATE TABLE profiles (id INTEGER PRIMARY KEY AUTOINCREMENT, ssid TEXT NOT NULL, ssid_hash TEXT NOT NULL UNIQUE, added_at TEXT NOT NULL, preferred INTEGER NOT NULL DEFAULT 0)');
        await db.execute('CREATE TABLE history (id INTEGER PRIMARY KEY AUTOINCREMENT, ssid TEXT NOT NULL, action TEXT NOT NULL, created_at TEXT NOT NULL, details TEXT NOT NULL DEFAULT "")');
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        if (oldVersion < 2) {
          await db.execute('ALTER TABLE profiles ADD COLUMN ssid_hash TEXT');
          final profiles = await db.query('profiles');
          for (final row in profiles) {
            final clear = (row['ssid'] as String?) ?? '';
            await db.update('profiles', {'ssid': await _secure.encryptText(clear), 'ssid_hash': _secure.fingerprint(clear)}, where: 'id = ?', whereArgs: [row['id']]);
          }
          final history = await db.query('history');
          for (final row in history) {
            final clearSsid = (row['ssid'] as String?) ?? '';
            final details = (row['details'] as String?) ?? '';
            await db.update('history', {'ssid': await _secure.encryptText(clearSsid), 'details': await _secure.encryptText(details)}, where: 'id = ?', whereArgs: [row['id']]);
          }
          await db.execute('CREATE UNIQUE INDEX IF NOT EXISTS idx_profiles_ssid_hash ON profiles(ssid_hash)');
        }
      });
    return _db!;
  }

  Future<List<AuthorizedProfile>> getProfiles() async {
    final rows = await (await database).query('profiles', orderBy: 'preferred DESC, added_at DESC');
    final result = <AuthorizedProfile>[];
    for (final row in rows) {
      final clear = await _secure.decryptText(row['ssid'] as String);
      result.add(AuthorizedProfile.fromMap({...row, 'ssid': clear}));
    }
    return result;
  }

  Future<void> addProfile(String ssid) async {
    final db = await database;
    final normalized = ssid.trim();
    final hash = _secure.fingerprint(normalized);
    final duplicate = await db.query('profiles', where: 'ssid_hash = ?', whereArgs: [hash], limit: 1);
    if (duplicate.isNotEmpty) return;
    await db.insert('profiles', {'ssid': await _secure.encryptText(normalized), 'ssid_hash': hash, 'added_at': DateTime.now().toIso8601String(), 'preferred': 0}, conflictAlgorithm: ConflictAlgorithm.ignore);
  }
  Future<void> removeProfile(int id) async => (await database).delete('profiles', where: 'id = ?', whereArgs: [id]);
  Future<void> setPreferred(int id) async {
    final db = await database;
    await db.transaction((txn) async { await txn.update('profiles', {'preferred': 0}); await txn.update('profiles', {'preferred': 1}, where: 'id = ?', whereArgs: [id]); });
  }
  Future<void> addHistory(String ssid, String action, {String details = ''}) async {
    await (await database).insert('history', {'ssid': await _secure.encryptText(ssid), 'action': action, 'created_at': DateTime.now().toIso8601String(), 'details': await _secure.encryptText(details)});
  }
  Future<List<ConnectionRecord>> getHistory({int limit = 200}) async {
    final rows = await (await database).query('history', orderBy: 'created_at DESC', limit: limit);
    final result = <ConnectionRecord>[];
    for (final row in rows) {
      result.add(ConnectionRecord.fromMap({...row, 'ssid': await _secure.decryptText(row['ssid'] as String), 'details': await _secure.decryptText(row['details'] as String)}));
    }
    return result;
  }
}
