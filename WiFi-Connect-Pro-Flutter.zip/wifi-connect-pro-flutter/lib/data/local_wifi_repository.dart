import '../models/authorized_profile.dart';
import '../models/connection_record.dart';
import 'app_database.dart';
import '../domain/repositories/wifi_repository.dart';

class LocalWifiRepository implements WifiRepository {
  LocalWifiRepository({AppDatabase? database}) : _database = database ?? AppDatabase.instance;
  final AppDatabase _database;
  @override Future<List<AuthorizedProfile>> getProfiles() => _database.getProfiles();
  @override Future<void> addProfile(String ssid) => _database.addProfile(ssid);
  @override Future<void> removeProfile(int id) => _database.removeProfile(id);
  @override Future<void> setPreferred(int id) => _database.setPreferred(id);
  @override Future<void> addHistory(String ssid, String action, {String details = ''}) => _database.addHistory(ssid, action, details: details);
  @override Future<List<ConnectionRecord>> getHistory({int limit = 200}) => _database.getHistory(limit: limit);
}
