import 'package:flutter/services.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:permission_handler/permission_handler.dart';
import '../models/wifi_network.dart';

class WifiService {
  static const _channel = MethodChannel('com.wificonnectpro/wifi');

  Future<bool> requestPermissions() async {
    final location = await Permission.locationWhenInUse.request();
    if (!location.isGranted) return false;
    // Nearby Wi-Fi is a runtime permission on recent Android versions; unsupported versions report granted/not applicable.
    final android = await DeviceInfoPlugin().androidInfo;
    if (android.version.sdkInt < 33) return true;
    final nearby = await Permission.nearbyWifiDevices.request();
    return nearby.isGranted || nearby.isLimited;
  }

  Future<List<WifiNetwork>> scan() async {
    final ok = await requestPermissions();
    if (!ok) throw PlatformException(code: 'PERMISSION_REQUIRED', message: 'Concede permisos de ubicación y dispositivos Wi-Fi cercanos para escanear.');
    final rows = await _channel.invokeListMethod<dynamic>('scanNetworks') ?? [];
    return rows.map((row) => WifiNetwork.fromMap(Map<dynamic, dynamic>.from(row as Map))).toList();
  }

  Future<Map<String, dynamic>> status() async {
    final value = await _channel.invokeMapMethod<dynamic, dynamic>('getConnectionStatus') ?? {};
    return Map<String, dynamic>.from(value);
  }

  Future<Map<String, dynamic>> connect(String ssid, String password, {String security = 'WPA2'}) async {
    if (ssid.trim().isEmpty) throw ArgumentError('El nombre de red es obligatorio.');
    final ok = await requestPermissions();
    if (!ok) throw PlatformException(code: 'PERMISSION_REQUIRED', message: 'Concede los permisos necesarios para solicitar la conexión.');
    final result = await _channel.invokeMapMethod<dynamic, dynamic>('connectWithSpecifier', {'ssid': ssid.trim(), 'password': password, 'security': security}) ?? {};
    return Map<String, dynamic>.from(result);
  }

  Future<Map<String, dynamic>> suggest(String ssid, String password, {String security = 'WPA2'}) async {
    final result = await _channel.invokeMapMethod<dynamic, dynamic>('addNetworkSuggestion', {'ssid': ssid.trim(), 'password': password, 'security': security}) ?? {};
    return Map<String, dynamic>.from(result);
  }
}
