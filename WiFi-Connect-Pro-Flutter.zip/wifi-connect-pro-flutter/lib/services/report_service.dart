import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import '../models/authorized_profile.dart';
import '../models/connection_record.dart';

class ReportService {
  Future<void> exportPdf(List<AuthorizedProfile> profiles, List<ConnectionRecord> history) async {
    final doc = pw.Document();
    final fmt = DateFormat('dd/MM/yyyy HH:mm');
    doc.addPage(pw.MultiPage(pageFormat: PdfPageFormat.a4, margin: const pw.EdgeInsets.all(32), build: (_) => [
      pw.Text('WiFi Connect Pro', style: pw.TextStyle(fontSize: 24, fontWeight: pw.FontWeight.bold)),
      pw.SizedBox(height: 4), pw.Text('Informe local · ${fmt.format(DateTime.now())}'),
      pw.SizedBox(height: 20), pw.Text('Perfiles autorizados', style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
      if (profiles.isEmpty) pw.Text('No hay perfiles guardados.') else pw.TableHelper.fromTextArray(headers: ['SSID', 'Registrado', 'Preferido'], data: profiles.map((p) => [p.ssid, fmt.format(p.addedAt), p.preferred ? 'Sí' : 'No']).toList()),
      pw.SizedBox(height: 20), pw.Text('Historial de operaciones', style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
      if (history.isEmpty) pw.Text('No hay operaciones registradas.') else pw.TableHelper.fromTextArray(headers: ['Fecha', 'Red', 'Acción', 'Detalle'], data: history.map((h) => [fmt.format(h.createdAt), h.ssid, h.action, h.details]).toList()),
      pw.SizedBox(height: 16), pw.Text('Este informe contiene metadatos locales; no incluye contraseñas.'),
    ]));
    await Printing.sharePdf(bytes: await doc.save(), filename: 'wifi_connect_pro_informe.pdf');
  }
}
