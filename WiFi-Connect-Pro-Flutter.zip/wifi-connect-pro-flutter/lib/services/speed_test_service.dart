import 'package:http/http.dart' as http;

class SpeedTestResult {
  const SpeedTestResult({required this.downloadMbps, required this.duration, required this.bytes});
  final double downloadMbps;
  final Duration duration;
  final int bytes;
}

/// Prueba bajo demanda. Descarga una muestra de hasta 5 MB; puede consumir datos
/// móviles si el usuario no está conectado por Wi-Fi. No se ejecuta en segundo plano.
class SpeedTestService {
  Future<SpeedTestResult> runDownloadTest({int bytes = 5000000}) async {
    final client = http.Client();
    final watch = Stopwatch()..start();
    try {
      final response = await client.get(
        Uri.https('speed.cloudflare.com', '/__down', {'bytes': '$bytes'}),
      ).timeout(const Duration(seconds: 25));
      watch.stop();
      if (response.statusCode != 200 || response.bodyBytes.isEmpty) {
        throw Exception('El servidor de prueba no respondió correctamente.');
      }
      final seconds = watch.elapsedMicroseconds / 1000000;
      if (seconds <= 0) throw Exception('No se pudo medir el tiempo de descarga.');
      final mbps = (response.bodyBytes.length * 8) / seconds / 1000000;
      return SpeedTestResult(downloadMbps: mbps, duration: watch.elapsed, bytes: response.bodyBytes.length);
    } finally {
      client.close();
    }
  }
}
