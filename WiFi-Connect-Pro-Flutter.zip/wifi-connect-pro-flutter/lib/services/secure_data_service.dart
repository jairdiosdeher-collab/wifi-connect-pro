import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:cryptography/cryptography.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Cifra campos sensibles con AES-256-GCM. La clave se guarda en almacenamiento
/// seguro de Android, protegido por la infraestructura de Android Keystore.
/// No sustituye el cifrado integral de SQLite (SQLCipher).
class SecureDataService {
  SecureDataService._();
  static final SecureDataService instance = SecureDataService._();
  static const _keyName = 'wifi_connect_pro_aes256_key_v1';
  static const FlutterSecureStorage _storage = FlutterSecureStorage();
  final AesGcm _algorithm = AesGcm.with256bits();
  Future<SecretKey>? _keyFuture;

  Future<SecretKey> get _key => _keyFuture ??= _loadOrCreateKey();

  Future<SecretKey> _loadOrCreateKey() async {
    var encoded = await _storage.read(key: _keyName);
    if (encoded == null) {
      final random = Random.secure();
      final bytes = List<int>.generate(32, (_) => random.nextInt(256));
      encoded = base64Encode(bytes);
      await _storage.write(key: _keyName, value: encoded);
    }
    return SecretKey(base64Decode(encoded));
  }

  Future<String> encryptText(String value) async {
    final box = await _algorithm.encrypt(utf8.encode(value), secretKey: await _key);
    return base64Encode([...box.nonce, ...box.mac.bytes, ...box.cipherText]);
  }

  Future<String> decryptText(String value) async {
    final bytes = base64Decode(value);
    if (bytes.length < 28) throw const FormatException('Campo cifrado incompleto');
    final nonce = bytes.sublist(0, 12);
    final mac = Mac(bytes.sublist(12, 28));
    final cipherText = bytes.sublist(28);
    final clear = await _algorithm.decrypt(SecretBox(cipherText, nonce: nonce, mac: mac), secretKey: await _key);
    return utf8.decode(clear);
  }

  /// Huella no reversible para evitar perfiles duplicados sin revelar el SSID.
  String fingerprint(String value) => sha256.convert(utf8.encode(value.trim().toLowerCase())).toString();
}
