import '../../models/authorized_profile.dart';
import '../../models/connection_record.dart';

abstract interface class WifiRepository {
  Future<List<AuthorizedProfile>> getProfiles();
  Future<void> addProfile(String ssid);
  Future<void> removeProfile(int id);
  Future<void> setPreferred(int id);
  Future<void> addHistory(String ssid, String action, {String details = ''});
  Future<List<ConnectionRecord>> getHistory({int limit = 200});
}
