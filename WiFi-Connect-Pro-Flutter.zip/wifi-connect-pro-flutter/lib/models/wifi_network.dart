class WifiNetwork {
  const WifiNetwork({required this.ssid, required this.security, required this.level, required this.rssi, required this.frequency, this.bssid});
  final String ssid;
  final String security;
  final int level;
  final int rssi;
  final int frequency;
  final String? bssid;

  factory WifiNetwork.fromMap(Map<dynamic, dynamic> map) => WifiNetwork(
    ssid: (map['ssid'] ?? '').toString(),
    security: (map['security'] ?? 'Desconocida').toString(),
    level: (map['level'] as num?)?.toInt() ?? 0,
    rssi: (map['rssi'] as num?)?.toInt() ?? -100,
    frequency: (map['frequency'] as num?)?.toInt() ?? 0,
    bssid: map['bssid']?.toString(),
  );

  String get band => frequency >= 5925 ? '6 GHz' : frequency >= 4900 ? '5 GHz' : '2.4 GHz';
  String get signalLabel => level >= 75 ? 'Excelente' : level >= 50 ? 'Buena' : level >= 25 ? 'Regular' : 'Débil';
}
