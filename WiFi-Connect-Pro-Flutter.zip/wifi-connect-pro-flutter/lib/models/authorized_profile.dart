class AuthorizedProfile {
  const AuthorizedProfile({required this.id, required this.ssid, required this.addedAt, this.preferred = false});
  final int? id;
  final String ssid;
  final DateTime addedAt;
  final bool preferred;
  Map<String, Object?> toMap() => {'id': id, 'ssid': ssid, 'added_at': addedAt.toIso8601String(), 'preferred': preferred ? 1 : 0};
  factory AuthorizedProfile.fromMap(Map<String, Object?> map) => AuthorizedProfile(
    id: map['id'] as int?, ssid: map['ssid'] as String,
    addedAt: DateTime.tryParse(map['added_at'] as String? ?? '') ?? DateTime.now(),
    preferred: (map['preferred'] as int? ?? 0) == 1,
  );
}
