class ConnectionRecord {
  const ConnectionRecord({this.id, required this.ssid, required this.action, required this.createdAt, this.details = ''});
  final int? id;
  final String ssid;
  final String action;
  final DateTime createdAt;
  final String details;
  Map<String, Object?> toMap() => {'id': id, 'ssid': ssid, 'action': action, 'created_at': createdAt.toIso8601String(), 'details': details};
  factory ConnectionRecord.fromMap(Map<String, Object?> map) => ConnectionRecord(
    id: map['id'] as int?, ssid: map['ssid'] as String, action: map['action'] as String,
    createdAt: DateTime.tryParse(map['created_at'] as String? ?? '') ?? DateTime.now(), details: map['details'] as String? ?? '');
}
