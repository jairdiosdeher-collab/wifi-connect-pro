import 'package:flutter/material.dart';
import '../models/wifi_network.dart';

class SignalBadge extends StatelessWidget {
  const SignalBadge({super.key, required this.network});
  final WifiNetwork network;
  @override
  Widget build(BuildContext context) {
    final color = network.level >= 70 ? Colors.greenAccent : network.level >= 40 ? Colors.amberAccent : Colors.orangeAccent;
    return Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(network.level >= 70 ? Icons.wifi : network.level >= 35 ? Icons.network_wifi_3_bar : Icons.network_wifi_1_bar, color: color, size: 18),
      const SizedBox(width: 5), Text('${network.level}% · ${network.signalLabel}', style: Theme.of(context).textTheme.labelSmall?.copyWith(color: color)),
    ]);
  }
}
