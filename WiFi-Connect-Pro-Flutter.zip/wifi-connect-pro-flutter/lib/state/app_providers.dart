import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../data/local_wifi_repository.dart';
import '../domain/repositories/wifi_repository.dart';
import '../services/report_service.dart';
import '../services/speed_test_service.dart';
import '../services/wifi_service.dart';

/// Dependencias de la aplicación: reemplazables en pruebas mediante ProviderScope.
final wifiServiceProvider = Provider<WifiService>((ref) => WifiService());
final wifiRepositoryProvider = Provider<WifiRepository>((ref) => LocalWifiRepository());
final reportServiceProvider = Provider<ReportService>((ref) => ReportService());
final speedTestServiceProvider = Provider<SpeedTestService>((ref) => SpeedTestService());
final themeModeProvider = StateProvider<ThemeMode>((ref) => ThemeMode.system);
