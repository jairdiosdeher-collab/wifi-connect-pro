import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

class WifiQrData {
  const WifiQrData({required this.ssid, required this.password, required this.security});
  final String ssid;
  final String password;
  final String security;
}

class QrScannerScreen extends StatefulWidget {
  const QrScannerScreen({super.key});
  @override
  State<QrScannerScreen> createState() => _QrScannerScreenState();
}

class _QrScannerScreenState extends State<QrScannerScreen> {
  bool _handled = false;
  String? _error;

  WifiQrData? _parse(String raw) {
    if (!raw.startsWith('WIFI:')) return null;
    final body = raw.substring(5).replaceAll(r'\;', '\u0001').replaceAll(r'\:', '\u0002').replaceAll(r'\\', '\u0003');
    final fields = <String, String>{};
    for (final part in body.split(';')) {
      final idx = part.indexOf(':');
      if (idx > 0) fields[part.substring(0, idx)] = part.substring(idx + 1).replaceAll('\u0001', ';').replaceAll('\u0002', ':').replaceAll('\u0003', r'\');
    }
    final ssid = fields['S'] ?? '';
    if (ssid.isEmpty) return null;
    return WifiQrData(ssid: ssid, password: fields['P'] ?? '', security: (fields['T'] ?? 'WPA2').toUpperCase());
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Leer QR Wi-Fi')),
    body: Column(children: [
      Expanded(child: MobileScanner(onDetect: (capture) {
        if (_handled) return;
        final raw = capture.barcodes.isEmpty ? null : capture.barcodes.first.rawValue;
        if (raw == null) return;
        final parsed = _parse(raw);
        if (parsed == null) { setState(() => _error = 'El QR no contiene datos Wi-Fi compatibles.'); return; }
        _handled = true;
        Navigator.of(context).pop(parsed);
      })),
      Padding(padding: const EdgeInsets.all(18), child: Column(children: [
        const Text('Escanea un QR de una red que tengas permiso para utilizar.', textAlign: TextAlign.center),
        if (_error != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error))),
      ])),
    ]),
  );
}
