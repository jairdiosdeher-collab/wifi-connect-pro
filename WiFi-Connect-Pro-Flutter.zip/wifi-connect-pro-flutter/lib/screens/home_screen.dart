import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../state/app_providers.dart';
import '../data/local_wifi_repository.dart';
import '../domain/repositories/wifi_repository.dart';
import '../models/authorized_profile.dart';
import '../models/connection_record.dart';
import '../models/wifi_network.dart';
import '../services/report_service.dart';
import '../services/wifi_service.dart';
import '../widgets/section_card.dart';
import '../widgets/signal_badge.dart';
import 'qr_scanner_screen.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});
  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  late final WifiService _wifi = ref.read(wifiServiceProvider);
  late final WifiRepository _repository = ref.read(wifiRepositoryProvider);
  late final ReportService _report = ref.read(reportServiceProvider);
  bool _speedTesting = false;
  double? _downloadMbps;
  String? _speedMessage;
  final Map<int, int> _coverageSamples = {};
  int _tab = 0;
  bool _scanning = false;
  List<WifiNetwork> _networks = [];
  List<AuthorizedProfile> _profiles = [];
  List<ConnectionRecord> _history = [];
  Map<String, dynamic> _status = {'connected': false};
  String? _message;

  @override
  void initState() { super.initState(); _reload(); }
  Future<void> _reload() async {
    try {
      final profiles = await _repository.getProfiles();
      final history = await _repository.getHistory();
      final status = await _wifi.status();
      if (!mounted) return;
      setState(() { _profiles = profiles; _history = history; _status = status; });
    } catch (e) { if (mounted) setState(() => _message = 'No se pudieron cargar los datos locales: $e'); }
  }

  Future<void> _scan() async {
    setState(() { _scanning = true; _message = null; });
    try {
      final rows = await _wifi.scan();
      if (!mounted) return;
      setState(() { _networks = rows; _message = rows.isEmpty ? 'Android no devolvió redes. Comprueba Wi-Fi, ubicación y permisos.' : '${rows.length} redes detectadas por Android.'; });
    } catch (e) { if (mounted) setState(() => _message = 'No se pudo escanear: $e'); }
    finally { if (mounted) setState(() => _scanning = false); }
  }

  Future<void> _refreshStatus() async { try { final s = await _wifi.status(); if (mounted) setState(() => _status = s); } catch (_) {} }

  Future<void> _addProfile([String? preset]) async {
    final controller = TextEditingController(text: preset ?? '');
    final accepted = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Perfil autorizado'), content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: controller, autofocus: true, maxLength: 32, decoration: const InputDecoration(labelText: 'Nombre exacto (SSID)', prefixIcon: Icon(Icons.wifi))),
        const SizedBox(height: 8), const Text('Confirma que eres titular de la red o tienes autorización para usarla.', style: TextStyle(fontSize: 12)),
      ]), actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Guardar'))],
    ));
    final ssid = controller.text.trim(); controller.dispose();
    if (accepted != true || ssid.isEmpty) return;
    await _repository.addProfile(ssid); await _repository.addHistory(ssid, 'Perfil añadido', details: 'Sin contraseña almacenada'); await _reload();
    if (mounted) _snack('Perfil guardado localmente. La contraseña no se almacena.');
  }

  Future<void> _connect(String ssid, {String? presetPassword, String security = 'WPA2'}) async {
    final matches = _profiles.where((p) => p.ssid.toLowerCase() == ssid.toLowerCase());
    final profile = matches.isEmpty ? null : matches.first;
    if (profile == null) { _snack('Guarda primero el perfil y confirma que tienes autorización.'); return; }
    final passwordController = TextEditingController(text: presetPassword ?? '');
    final securityChoice = ValueNotifier<String>(security.contains('WPA3') ? 'WPA3' : 'WPA2');
    final go = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: Text('Conectar a $ssid'), content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('Android mostrará el consentimiento del sistema si corresponde. La contraseña solo se transmite para esta solicitud y no se guarda en SQLite.'),
        const SizedBox(height: 12), TextField(controller: passwordController, obscureText: true, decoration: const InputDecoration(labelText: 'Contraseña (si la red la requiere)', prefixIcon: Icon(Icons.lock))),
        const SizedBox(height: 12), ValueListenableBuilder<String>(valueListenable: securityChoice, builder: (_, value, __) => DropdownButtonFormField<String>(value: value, decoration: const InputDecoration(labelText: 'Seguridad'), items: const [DropdownMenuItem(value: 'WPA2', child: Text('WPA2 / WPA')), DropdownMenuItem(value: 'WPA3', child: Text('WPA3')), DropdownMenuItem(value: 'OPEN', child: Text('Red abierta'))], onChanged: (v) { if (v != null) securityChoice.value = v; })),
      ])), actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')), FilledButton.icon(onPressed: () => Navigator.pop(ctx, true), icon: const Icon(Icons.wifi), label: const Text('Solicitar'))],
    ));
    if (go != true) { passwordController.dispose(); securityChoice.dispose(); return; }
    try {
      final result = await _wifi.connect(ssid, passwordController.text, security: securityChoice.value);
      await _repository.addHistory(ssid, 'Conexión solicitada', details: (result['message'] ?? 'Solicitud enviada').toString());
      if (mounted) _snack((result['message'] ?? 'Solicitud enviada a Android.').toString());
    } catch (e) {
      await _repository.addHistory(ssid, 'Solicitud fallida', details: e.toString());
      if (mounted) _snack('No se pudo solicitar la conexión: $e');
    } finally { passwordController.dispose(); securityChoice.dispose(); await _reload(); }
  }

  Future<void> _preferred() async {
    if (_profiles.isEmpty) { _snack('Añade un perfil autorizado primero.'); return; }
    final profile = _profiles.firstWhere((p) => p.preferred, orElse: () => _profiles.first);
    final found = _networks.any((n) => n.ssid == profile.ssid);
    if (!found) { _snack('Escanea redes y confirma que la red preferida esté cerca.'); return; }
    await _connect(profile.ssid, security: _networks.firstWhere((n) => n.ssid == profile.ssid).security);
  }

  Future<void> _suggestNetwork(AuthorizedProfile profile) async {
    final passwordController = TextEditingController();
    final security = ValueNotifier<String>('WPA2');
    final accepted = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Preparar reconexión automática'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        Text('Solicitarás a Android registrar una sugerencia para “${profile.ssid}”. Android puede pedir aprobación y decide si se reconecta. La contraseña no se guarda en la base de esta app.'),
        const SizedBox(height: 12),
        TextField(controller: passwordController, obscureText: true, decoration: const InputDecoration(labelText: 'Contraseña de la red', prefixIcon: Icon(Icons.lock))),
        const SizedBox(height: 12),
        ValueListenableBuilder<String>(valueListenable: security, builder: (_, value, __) => DropdownButtonFormField<String>(value: value, decoration: const InputDecoration(labelText: 'Seguridad'), items: const [DropdownMenuItem(value: 'WPA2', child: Text('WPA2 / WPA')), DropdownMenuItem(value: 'WPA3', child: Text('WPA3')), DropdownMenuItem(value: 'OPEN', child: Text('Red abierta'))], onChanged: (v) { if (v != null) security.value = v; })),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Solicitar a Android'))],
    ));
    if (accepted != true) { passwordController.dispose(); security.dispose(); return; }
    try {
      final result = await _wifi.suggest(profile.ssid, passwordController.text, security: security.value);
      await _repository.addHistory(profile.ssid, 'Sugerencia de red', details: (result['message'] ?? 'Android recibió la solicitud.').toString());
      if (mounted) _snack((result['message'] ?? 'Solicitud enviada a Android.').toString());
    } catch (e) {
      if (mounted) _snack('No se pudo registrar la sugerencia: $e');
    } finally {
      passwordController.dispose(); security.dispose(); await _reload();
    }
  }

  Future<void> _setPreferred(AuthorizedProfile profile) async {
    if (profile.id == null) return;
    await _repository.setPreferred(profile.id!); await _repository.addHistory(profile.ssid, 'Preferencia actualizada'); await _reload();
  }

  Future<void> _deleteProfile(AuthorizedProfile profile) async {
    if (profile.id == null) return;
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(title: const Text('Eliminar perfil'), content: Text('¿Eliminar ${profile.ssid} de los perfiles guardados?'), actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Eliminar'))]));
    if (ok != true) return;
    await _repository.removeProfile(profile.id!); await _repository.addHistory(profile.ssid, 'Perfil eliminado'); await _reload();
  }

  Future<void> _openQr() async {
    final data = await Navigator.of(context).push<WifiQrData>(MaterialPageRoute(builder: (_) => const QrScannerScreen()));
    if (data == null || !mounted) return;
    await _addProfile(data.ssid);
    if (!mounted) return;
    final shouldConnect = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(title: const Text('QR Wi-Fi leído'), content: Text('Red: ${data.ssid}\nLa contraseña leída no se guardará. ¿Solicitar conexión ahora?'), actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Después')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Conectar'))]));
    if (shouldConnect == true) await _connect(data.ssid, presetPassword: data.password, security: data.security);
  }

  Future<void> _runSpeedTest() async {
    setState(() { _speedTesting = true; _speedMessage = 'Midiendo descarga (muestra de hasta 5 MB)…'; });
    try {
      final result = await ref.read(speedTestServiceProvider).runDownloadTest();
      if (!mounted) return;
      setState(() { _downloadMbps = result.downloadMbps; _speedMessage = '${result.downloadMbps.toStringAsFixed(1)} Mbps · ${result.duration.inMilliseconds} ms · ${(result.bytes / 1000000).toStringAsFixed(1)} MB'; });
    } catch (e) {
      if (mounted) setState(() => _speedMessage = 'Prueba no disponible: $e');
    } finally { if (mounted) setState(() => _speedTesting = false); }
  }

  void _recordCoveragePoint(int cell) {
    final status = _status;
    final rssi = (status['rssi'] as num?)?.toInt();
    if (status['connected'] != true || rssi == null) {
      _snack('Conéctate a una red Wi-Fi para registrar una muestra de cobertura.');
      return;
    }
    setState(() => _coverageSamples[cell] = rssi);
    _snack('Muestra de señal registrada. Las muestras son locales y no incluyen ubicación GPS.');
  }

  Future<void> _export() async {
    try { await _report.exportPdf(_profiles, _history); } catch (e) { _snack('No se pudo crear el PDF: $e'); }
  }

  void _snack(String text) { if (!mounted) return; ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text), behavior: SnackBarBehavior.floating)); }

  @override
  Widget build(BuildContext context) {
    final pages = [_dashboard(), _profilesPage(), _historyPage(), _settingsPage()];
    return Scaffold(
      appBar: AppBar(title: const Row(children: [Icon(Icons.wifi, color: Color(0xFF75A7FF)), SizedBox(width: 10), Text('WiFi Connect Pro')]), actions: [IconButton(tooltip: 'Leer QR Wi-Fi', onPressed: _openQr, icon: const Icon(Icons.qr_code_scanner))]),
      body: SafeArea(child: IndexedStack(index: _tab, children: pages)),
      floatingActionButton: _tab == 1 ? FloatingActionButton.extended(onPressed: () => _addProfile(), icon: const Icon(Icons.add), label: const Text('Añadir perfil')) : null,
      bottomNavigationBar: NavigationBar(selectedIndex: _tab, onDestinationSelected: (v) => setState(() => _tab = v), destinations: const [NavigationDestination(icon: Icon(Icons.radar), label: 'Redes'), NavigationDestination(icon: Icon(Icons.verified_user_outlined), label: 'Perfiles'), NavigationDestination(icon: Icon(Icons.history), label: 'Historial'), NavigationDestination(icon: Icon(Icons.tune), label: 'Ajustes')]),
    );
  }

  Widget _dashboard() => RefreshIndicator(onRefresh: _refreshStatus, child: ListView(padding: const EdgeInsets.fromLTRB(12, 10, 12, 100), children: [
    SectionCard(title: 'Estado de conexión', icon: Icons.router, trailing: IconButton(onPressed: _refreshStatus, icon: const Icon(Icons.refresh)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Icon(_status['connected'] == true ? Icons.wifi : Icons.wifi_off, size: 36, color: _status['connected'] == true ? Colors.greenAccent : Colors.blueGrey), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(_status['connected'] == true ? (_status['ssid'] ?? 'Conectado').toString() : 'Estado de Wi-Fi no conectado', style: Theme.of(context).textTheme.titleMedium), Text(_status['connected'] == true ? 'Conexión informada por Android' : 'Android informa que no hay una red Wi-Fi activa', style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Theme.of(context).colorScheme.onSurfaceVariant))]))]),
      if (_status['level'] != null) Padding(padding: const EdgeInsets.only(top: 10), child: Text('Señal ${_status['level']}% · RSSI ${_status['rssi']} dBm · ${_status['linkSpeedMbps'] ?? '—'} Mbps')),
      const SizedBox(height: 10), FilledButton.icon(onPressed: _scanning ? null : _scan, icon: _scanning ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.radar), label: Text(_scanning ? 'Escaneando…' : 'Escanear redes cercanas'), style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(46))),
      OutlinedButton.icon(onPressed: _preferred, icon: const Icon(Icons.bolt), label: const Text('Solicitar conexión a perfil preferido'), style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(44))),
    ])),
    if (_message != null) Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Text(_message!, style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Theme.of(context).colorScheme.secondary))),
    SectionCard(title: 'Redes detectadas', icon: Icons.wifi_find, trailing: Text('${_networks.length}', style: Theme.of(context).textTheme.labelLarge), child: _networks.isEmpty ? const _EmptyState(icon: Icons.wifi_find, text: 'Pulsa “Escanear redes cercanas”. Los resultados procederán de Android; no se mostrarán redes simuladas.') : Column(children: _networks.map(_networkTile).toList())),
    SectionCard(title: 'Velocidad de Internet', icon: Icons.speed, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(crossAxisAlignment: CrossAxisAlignment.end, children: [Text(_downloadMbps == null ? '—' : _downloadMbps!.toStringAsFixed(1), style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)), const SizedBox(width: 8), const Padding(padding: EdgeInsets.only(bottom: 5), child: Text('Mbps de descarga'))]),
      if (_speedMessage != null) Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Text(_speedMessage!)),
      const Text('Prueba manual con descarga de hasta 5 MB. Puede consumir datos; úsala solo cuando lo desees.'),
      const SizedBox(height: 10), FilledButton.icon(onPressed: _speedTesting ? null : _runSpeedTest, icon: _speedTesting ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.play_arrow), label: Text(_speedTesting ? 'Midiendo…' : 'Medir velocidad')),
    ])),
    SectionCard(title: 'Mapa esquemático de cobertura', icon: Icons.grid_view, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Toca una celda desde cada punto del espacio mientras estás conectado. Se registra la señal RSSI actual en este dispositivo; no se usa GPS.'),
      const SizedBox(height: 12),
      GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: 3, crossAxisSpacing: 8, mainAxisSpacing: 8, children: List.generate(9, (index) {
        final value = _coverageSamples[index];
        final color = value == null ? Theme.of(context).colorScheme.surfaceContainerHighest : value >= -55 ? Colors.green.shade700 : value >= -67 ? Colors.lightGreen.shade700 : value >= -75 ? Colors.orange.shade700 : Colors.red.shade700;
        return InkWell(borderRadius: BorderRadius.circular(12), onTap: () => _recordCoveragePoint(index), child: Container(decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(12), border: Border.all(color: Theme.of(context).colorScheme.outlineVariant)), child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(value == null ? Icons.add_location_alt_outlined : Icons.wifi, color: value == null ? Theme.of(context).colorScheme.onSurfaceVariant : Colors.white), const SizedBox(height: 4), Text('Punto ${index + 1}', style: TextStyle(color: value == null ? Theme.of(context).colorScheme.onSurfaceVariant : Colors.white, fontWeight: FontWeight.w600)), Text(value == null ? 'Sin muestra' : '$value dBm', style: TextStyle(color: value == null ? Theme.of(context).colorScheme.onSurfaceVariant : Colors.white, fontSize: 12))]))));
      })),
      const SizedBox(height: 8), const Text('Verde = señal fuerte · naranja = media · rojo = débil. Es un plano de muestreo manual, no un mapa geográfico.'),
    ])),
    SectionCard(
      title: 'Perfiles autorizados', icon: Icons.verified_user,
      trailing: Text('${_profiles.length}'),
      child: _profiles.isEmpty
          ? const _EmptyState(icon: Icons.shield_outlined, text: 'Guarda redes propias o autorizadas para gestionar tus perfiles.')
          : Column(children: _profiles.take(3).map(_profilePreviewTile).toList()),
    ),
    const Padding(padding: EdgeInsets.all(8), child: Text('🔐 Solo redes propias o expresamente autorizadas. Android controla el consentimiento y la conexión real.', textAlign: TextAlign.center)),
  ]));

  Widget _profilePreviewTile(AuthorizedProfile profile) {
    final matching = _networks.where((network) => network.ssid == profile.ssid);
    final security = matching.isEmpty ? 'WPA2' : matching.first.security;
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: const Icon(Icons.wifi),
      title: Text(profile.ssid),
      subtitle: Text(profile.preferred ? 'Perfil preferido' : 'Perfil local'),
      trailing: IconButton(
        icon: const Icon(Icons.link),
        tooltip: 'Solicitar conexión',
        onPressed: () => _connect(profile.ssid, security: security),
      ),
    );
  }

  Widget _profileCard(AuthorizedProfile profile) => Card(
    color: Theme.of(context).colorScheme.surfaceContainerLow,
    child: ListTile(
      leading: Icon(profile.preferred ? Icons.star : Icons.wifi, color: profile.preferred ? Colors.amber : null),
      title: Text(profile.ssid),
      subtitle: Text('Añadida ${profile.addedAt.toLocal().toString().split('.').first}'),
      trailing: PopupMenuButton<String>(
        onSelected: (value) {
          if (value == 'preferred') _setPreferred(profile);
          if (value == 'connect') _connect(profile.ssid);
          if (value == 'suggest') _suggestNetwork(profile);
          if (value == 'delete') _deleteProfile(profile);
        },
        itemBuilder: (_) => const [
          PopupMenuItem(value: 'preferred', child: Text('Marcar preferida')),
          PopupMenuItem(value: 'connect', child: Text('Solicitar conexión ahora')),
          PopupMenuItem(value: 'suggest', child: Text('Preparar reconexión automática')),
          PopupMenuItem(value: 'delete', child: Text('Eliminar perfil')),
        ],
        icon: const Icon(Icons.more_vert),
      ),
    ),
  );

  Widget _networkTile(WifiNetwork n) {
    final authorized = _profiles.any((p) => p.ssid == n.ssid);
    return ListTile(contentPadding: EdgeInsets.zero, leading: CircleAvatar(backgroundColor: Theme.of(context).colorScheme.surfaceContainerHighest, child: Icon(Icons.wifi, color: Theme.of(context).colorScheme.primary)), title: Text(n.ssid, maxLines: 1, overflow: TextOverflow.ellipsis), subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${n.security} · ${n.band} · ${n.frequency} MHz'), const SizedBox(height: 3), SignalBadge(network: n)]), isThreeLine: true, trailing: IconButton(tooltip: authorized ? 'Conectar' : 'Guardar perfil', onPressed: () => authorized ? _connect(n.ssid, security: n.security) : _addProfile(n.ssid), icon: Icon(authorized ? Icons.link : Icons.add_circle_outline)));
  }

  Widget _profilesPage() => ListView(padding: const EdgeInsets.all(12), children: [
    SectionCard(
      title: 'Perfiles autorizados', icon: Icons.verified_user,
      child: _profiles.isEmpty
          ? const _EmptyState(icon: Icons.shield_outlined, text: 'Todavía no hay perfiles guardados.')
          : Column(children: _profiles.map(_profileCard).toList()),
    ),
    const Padding(padding: EdgeInsets.all(8), child: Text('SQLite guarda SSID y metadatos. No se almacenan contraseñas.', textAlign: TextAlign.center)),
  ]);

  Widget _historyPage() => ListView(padding: const EdgeInsets.all(12), children: [
    SectionCard(title: 'Historial local', icon: Icons.history, trailing: IconButton(onPressed: _reload, icon: const Icon(Icons.refresh)), child: _history.isEmpty ? const _EmptyState(icon: Icons.history, text: 'Las solicitudes de conexión y cambios de perfil aparecerán aquí.') : Column(children: _history.map((h) => ListTile(contentPadding: EdgeInsets.zero, leading: Icon(h.action.contains('fallida') ? Icons.error_outline : Icons.event_note), title: Text(h.ssid), subtitle: Text('${h.action}\n${h.createdAt.toLocal().toString().split('.').first}${h.details.isNotEmpty ? '\n${h.details}' : ''}'), isThreeLine: true)).toList())),
    FilledButton.icon(onPressed: _export, icon: const Icon(Icons.picture_as_pdf), label: const Text('Exportar historial y perfiles a PDF')),
  ]);

  Widget _settingsPage() => ListView(padding: const EdgeInsets.all(12), children: [
    SectionCard(title: 'Diagnóstico', icon: Icons.monitor_heart_outlined, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Perfiles locales: ${_profiles.length}'), Text('Eventos históricos: ${_history.length}'), Text('Redes visibles en el último escaneo: ${_networks.length}'), const SizedBox(height: 12), const Text('La intensidad se estima con el RSSI devuelto por Android. La prueba de velocidad requiere acceso a Internet y un servicio de medición; no se ejecuta automáticamente para evitar consumo de datos.'), const SizedBox(height: 10), OutlinedButton.icon(onPressed: _scan, icon: const Icon(Icons.refresh), label: const Text('Actualizar diagnóstico'))])),
    SectionCard(title: 'Apariencia', icon: Icons.palette_outlined, child: DropdownButtonFormField<ThemeMode>(value: ref.watch(themeModeProvider), decoration: const InputDecoration(labelText: 'Tema de la aplicación'), items: const [DropdownMenuItem(value: ThemeMode.system, child: Text('Seguir el sistema')), DropdownMenuItem(value: ThemeMode.light, child: Text('Claro')), DropdownMenuItem(value: ThemeMode.dark, child: Text('Oscuro'))], onChanged: (value) { if (value != null) ref.read(themeModeProvider.notifier).state = value; })),
    SectionCard(title: 'Privacidad y compatibilidad', icon: Icons.privacy_tip_outlined, child: const Text('No se descifran contraseñas ni se accede a redes ajenas. Android controla el consentimiento de conexión. Los SSID y detalles del historial se cifran con AES-256-GCM; la clave se guarda en almacenamiento seguro protegido por Android Keystore. La base SQLite no está cifrada íntegramente con SQLCipher. No se almacenan contraseñas Wi-Fi.')),
    SectionCard(title: 'Exportación', icon: Icons.ios_share, child: FilledButton.icon(onPressed: _export, icon: const Icon(Icons.picture_as_pdf), label: const Text('Generar informe PDF'))),
  ]);
}

class _EmptyState extends StatelessWidget {
  const _EmptyState({required this.icon, required this.text});
  final IconData icon;
  final String text;
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 6), child: Column(children: [Icon(icon, size: 34, color: Theme.of(context).colorScheme.onSurfaceVariant), const SizedBox(height: 9), Text(text, textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Theme.of(context).colorScheme.onSurfaceVariant))]));
}
