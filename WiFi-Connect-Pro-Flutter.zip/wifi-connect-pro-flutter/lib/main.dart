import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'screens/home_screen.dart';
import 'state/app_providers.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ProviderScope(child: WiFiConnectProApp()));
}

class WiFiConnectProApp extends ConsumerWidget {
  const WiFiConnectProApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    const seed = Color(0xFF4F8CFF);
    final mode = ref.watch(themeModeProvider);
    return MaterialApp(
      title: 'WiFi Connect Pro',
      debugShowCheckedModeBanner: false,
      themeMode: mode,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: seed, brightness: Brightness.light),
        scaffoldBackgroundColor: const Color(0xFFF5F7FB),
        cardTheme: CardThemeData(elevation: 0, margin: const EdgeInsets.symmetric(vertical: 8), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
        inputDecorationTheme: InputDecorationTheme(filled: true, border: OutlineInputBorder(borderRadius: BorderRadius.circular(12))),
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(seedColor: seed, brightness: Brightness.dark).copyWith(surface: const Color(0xFF121D30), primary: const Color(0xFF75A7FF), secondary: const Color(0xFF20C997)),
        scaffoldBackgroundColor: const Color(0xFF0B1220),
        appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF0B1220), elevation: 0, centerTitle: false),
        cardTheme: CardThemeData(color: const Color(0xFF121D30), elevation: 0, margin: const EdgeInsets.symmetric(vertical: 8), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: const BorderSide(color: Color(0xFF283850)))),
        inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: const Color(0xFF0B1526), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)), enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFF31435C)))),
        navigationBarTheme: const NavigationBarThemeData(backgroundColor: Color(0xFF101A2B), indicatorColor: Color(0xFF203B60)),
      ),
      home: const HomeScreen(),
    );
  }
}
